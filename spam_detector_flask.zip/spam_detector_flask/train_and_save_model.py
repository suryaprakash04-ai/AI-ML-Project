import pandas as pd
import pickle
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, classification_report 

data= {
    'text': [
        'Win money now',
        'Limited offer just for you',
        'Hi, how are you?',
        'Call me tomorrow',
        'Free tickets available',
        'Congratulations, you won a prize!',
        'Are you coming to the party?',
        'Lets grab lunch today',
        'Earn extra cash fast',
        'Meeting at 3 PM',
    ],
    'Label':[1, 1, 0, 0, 1, 1, 0, 0, 1, 0]
}

df = pd.DataFrame(data)

vectorizer = CountVectorizer()
X = vectorizer.fit_transform(df['text'])
y = df['Label']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = MultinomialNB()

model.fit(X_train, y_train)
y_pred = model.predict(X_test)

print("Accuracy:", accuracy_score(y_test, y_pred))
print("Classification Report:\n", classification_report(y_test, y_pred))

# Save model and vectorizer
with open('model.pkl', 'wb') as model_file:
 pickle.dump(model, model_file)
with open('vectorizer.pkl', 'wb') as vec_file:
 pickle.dump(vectorizer, vec_file)
print("Model and vectorizer saved!")