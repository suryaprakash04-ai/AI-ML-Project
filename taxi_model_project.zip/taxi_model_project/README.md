# FareSight-Predict-Weekly-Taxi-Demand-with-Machine-Learning
FareSight forecasts weekly taxi demand using real urban metrics—price, population, income &amp; parking. With a custom UI and a trained ML model (scikit-learn + Flask), it simulates smart-city decision-making. Designed to demo real-world ML deployment in action.
