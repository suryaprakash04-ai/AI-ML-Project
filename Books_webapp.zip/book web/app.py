import streamlit as st
import pandas as pd
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# Load Data
books = pd.read_csv("books.csv")
ratings = pd.read_csv("ratings.csv")  # Add your ratings.csv here

# --- Content-Based Preprocessing ---
books['features'] = books['Title'] + " " + books['Author'] + " " + books['Genre']
tfidf = TfidfVectorizer()
tfidf_matrix = tfidf.fit_transform(books['features'])
content_similarity = cosine_similarity(tfidf_matrix)

# --- Collaborative Filtering Preprocessing ---
user_item_matrix = ratings.pivot_table(index='User_ID', columns='Book_ID', values='Rating').fillna(0)
user_similarity = cosine_similarity(user_item_matrix)
user_similarity_df = pd.DataFrame(user_similarity, index=user_item_matrix.index, columns=user_item_matrix.index)

# --- UI ---
st.title("📚 Book Recommender System")
tab1, tab2, tab3 = st.tabs(["Content-Based", "Collaborative", "Hybrid"])

# ------------------------- Tab 1: Content-Based -------------------------
with tab1:
    st.header("🔍 Content-Based Recommendations")
    book_titles = books['Title'].tolist()
    selected = st.selectbox("Choose a Book", book_titles, key="cb_book")

    if st.button("Recommend", key="cb_recommend"):
        index = books[books['Title'] == selected].index[0]
        similar_books = content_similarity[index].argsort()[::-1][1:4]
        st.write("### Recommended Books:")
        for i in similar_books:
            st.write("- " + books.iloc[i]['Title'])

# ------------------------- Tab 2: Collaborative Filtering -------------------------
with tab2:
    st.header("👤 Collaborative Filtering (User-Based)")
    user_ids = user_item_matrix.index.tolist()
    selected_user = st.selectbox("Choose a User ID", user_ids)

    if st.button("Recommend", key="cf_recommend"):
        # Get ratings from similar users
        sim_users = user_similarity_df.loc[selected_user].sort_values(ascending=False)[1:4].index
        sim_ratings = user_item_matrix.loc[sim_users].mean().sort_values(ascending=False)

        # Recommend unrated books
        user_rated_books = user_item_matrix.loc[selected_user][user_item_matrix.loc[selected_user] > 0].index
        recommendations = sim_ratings.drop(user_rated_books).head(3)

        st.write("### Recommended Books:")
        for book_id in recommendations.index:
            title = books[books['Book_ID'] == book_id]['Title'].values[0]
            st.write("- " + title)

# ------------------------- Tab 3: Hybrid -------------------------
with tab3:
    st.header("🧠 Hybrid Recommendations")
    selected_user_h = st.selectbox("Choose User ID", user_ids, key="hy_user")
    selected_book = st.selectbox("Choose a Book", books['Title'].tolist(), key="hy_book")

    if st.button("Recommend", key="hy_recommend"):
        book_id = books[books['Title'] == selected_book]['Book_ID'].values[0]
        book_index = books[books['Book_ID'] == book_id].index[0]

        content_scores = content_similarity[book_index]
        user_ratings = user_item_matrix.loc[selected_user_h]
        aligned_ratings = user_ratings.reindex(books['Book_ID']).fillna(0).values

        hybrid_score = 0.6 * content_scores + 0.4 * aligned_ratings
        top_indices = np.argsort(hybrid_score)[::-1]
        recommended_indices = [i for i in top_indices if i != book_index][:3]

        st.write("### Recommended Books:")
        for i in recommended_indices:
            st.write("- " + books.iloc[i]['Title'])

tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8, tab9 = st.tabs([
    "Content-Based",
    "Collaborative",
    "Hybrid",
    "Top Rated",
    "Genre-wise",
    "Author-wise",
    "User Stats",
    "New Arrivals",
    "Surprise Me!"
])

# ------------------------- Tab 4: Top Rated -------------------------
with tab1:
    st.header("🎭 Genre-wise Recommendations")
    genres = books["Genre"].unique().tolist()
    selected_genre = st.selectbox("Choose a Genre", genres)  # USER VALUE
    st.write(f"## You selected: {selected_genre}")            # Displays selected value
    genre_books = books[books["Genre"] == selected_genre]["Title"].tolist()
    st.write("### Books in this genre:")
    for title in genre_books:
        st.write("- " + title)
# ------------------------- Tab 5: Author-wise -------------------------
with tab2:
    st.header("🏆 Top Rated Books")
    n = st.slider("How many top books?", 1, 10, 5)          # USER VALUE
    avg_ratings = ratings.groupby("Book_ID")["Rating"].mean()
    top_books = avg_ratings.sort_values(ascending=False).head(n).index
    for book_id in top_books:
        title = books[books["Book_ID"] == book_id]["Title"].values[0]
        st.write("- " + title)

# ------------------------- Tab 9: Surprise Me! Hidden Gem -------------------------
with tab9:
    st.header("🎁 Surprise Me! - Hidden Gems")
    # Hidden gem logic: select books with few ratings or low popularity
    rated_counts = ratings.groupby('Book_ID')['Rating'].count()
    # Let's say books with less than 5 ratings = hidden gem
    hidden_gems = books[books['Book_ID'].isin(rated_counts[rated_counts < 5].index)]
    if not hidden_gems.empty:
        random_book = hidden_gems.sample(1).iloc[0]
        st.write(f"#### Try this hidden gem!")
        st.write(f"**{random_book['Title']}** by {random_book['Author']}")
        st.write(f"Genre: {random_book['Genre']}")
        if 'Year' in random_book:
            st.write(f"Published: {random_book['Year']}")
    else:
        st.write("Every book is popular! No hidden gems found.")
tab1, tab2 = st.tabs(["Genre-wise", "Top Rated"])


